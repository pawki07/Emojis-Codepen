emojis = document.querySelectorAll(".emoji");

function changeEmoji(i) {
  document.querySelector(".active").classList.remove("active");
  emojis[i].classList.add("active");
}
